require 'sinatra'

get '/' do
  'hello, world!'
end
