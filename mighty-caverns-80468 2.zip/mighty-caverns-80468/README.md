# Sinatra CMS Application Assessment
View on Wiki</a> (https://github.com/mrsdo/sinatra-cms-app-assessment/wiki)

